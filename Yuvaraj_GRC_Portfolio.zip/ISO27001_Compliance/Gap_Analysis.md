# Gap Analysis

Comparison with real-world ISO 27001 implementation at Infosys.